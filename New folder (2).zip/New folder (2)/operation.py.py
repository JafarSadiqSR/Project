#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from flask import Flask, render_template, request, redirect, url_for, send_file
import os
import pandas as pd

app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'admin'

files = {}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload():
    if 'file' not in request.files:
        return redirect(request.url)
    file = request.files['file']
    
    if file.filename == '':
        return redirect(request.url)
    if file:
        filename = file.filename
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
        files[filename] = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        return redirect(url_for('admin_panel'))

@app.route('/admin', methods=['GET', 'POST'])
def admin_panel():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            return redirect(url_for('admin_panel'))
    if 'username' not in session:
        return render_template('login.html')
    files_list = []
    for i, file in enumerate(files.keys()):
        files_list.append({
            'sno': i+1,
            'filename': file
        })
    return render_template('admin_panel.html', files=files_list)

@app.route('/download/<filename>')
def download_file(filename):
    path = files.get(filename)
    return send_file(path, as_attachment=True)

@app.route('/open/<filename>')
def open_file(filename):
    path = files.get(filename)
    data = pd.read_csv(path) if path.endswith('.csv') else pd.read_excel(path)
    return render_template('table.html', data=data.to_html())

if __name__ == '__main__':
    app.run(debug=True)

