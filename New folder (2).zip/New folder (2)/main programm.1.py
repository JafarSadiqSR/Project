#!/usr/bin/env python
# coding: utf-8

# In[1]:


from flask import Flask, render_template, request, redirect, url_for, send_file
import os
import pandas as pd

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'

ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'admin'


def is_admin_authenticated():
    """Checks if the user is authenticated as admin"""
    return request.cookies.get('admin_authenticated') == 'true'


@app.route('/')
def index():
    """Homepage"""
    return render_template('index.html')


@app.route('/upload', methods=['POST'])
def upload():
    """Handles file uploads"""
    if not is_admin_authenticated():
        return redirect(url_for('admin_login'))
    if 'file' not in request.files:
        return 'No file uploaded', 400

    # Get the file and save it to the UPLOAD_FOLDER
    file = request.files['file']
    if file.filename == '':
        return 'No file selected', 400

    file.save(os.path.join(app.config['UPLOAD_FOLDER'], file.filename))

    # Redirect to the admin panel
    return redirect(url_for('admin_panel'))


@app.route('/admin')
def admin_login():
    """Admin login page"""
    # Check if the user is already authenticated
    if is_admin_authenticated():
        return redirect(url_for('admin_panel'))

    return render_template('admin_login.html')


@app.route('/admin/authenticate', methods=['POST'])
def admin_authenticate():
    """Authenticates admin login"""
    username = request.form.get('username')
    password = request.form.get('password')

    if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
        response = redirect(url_for('admin_panel'))
        response.set_cookie('admin_authenticated', 'true')
        return response

    return 'Invalid username or password', 401


@app.route('/admin/panel')
def admin_panel():
    """Admin panel page"""
    if not is_admin_authenticated():
        return redirect(url_for('admin_login'))
    files = os.listdir(app.config['UPLOAD_FOLDER'])
    file_data = []
    for file_name in files:
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], file_name)
        file_size = os.path.getsize(file_path)
        file_data.append({
            'name': file_name,
            'size': file_size,
        })

    return render_template('admin_panel.html', files=file_data)


@app.route('/file/<file_name>/download')
def download_file(file_name):
    """Downloads the specified file"""
    if not is_admin_authenticated():
        return redirect(url_for('admin_login'))
    # Get the path of the file
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], file_name)
    # Download the file
    return send_file(file_path, as_attachment=True)


@app.route('/file/<file_name>/open')
def open_file(file_name):
    """Displays the contents of the specified file as a table"""
    # Check if the user is authenticated as admin
    if not is_admin_authenticated():
        return redirect(url_for('admin_login'))
    # Get the path of the file
    file_path = os.path.join(app.config['UPLOAD_FOLDER'], file_name)
    # Load the file using Pandas
    if file_name.endswith('.csv'):
        df = pd.read_csv(file_path)
   


# In[ ]:




